package com.example.intermediate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntermediateApplicationTests {

  @Test
  void contextLoads() {
  }

}
