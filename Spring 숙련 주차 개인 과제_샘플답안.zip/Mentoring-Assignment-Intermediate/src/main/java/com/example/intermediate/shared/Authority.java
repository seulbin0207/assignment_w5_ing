package com.example.intermediate.shared;

public enum Authority {
  ROLE_MEMBER,
  ROLE_GUEST
}
